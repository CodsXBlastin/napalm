# How to use?

Once running the loader, move the dll into your games directory;
e.g.: "C:\Program Files (x86)\Ubisoft\Ubisoft Game Launcher\games\Tom Clancy's Rainbow Six Siege", or 
"C:\Program Files (x86)\Steam\steamapps\common\Tom Clancy's Rainbow Six Siege"

then run the RainbowSix.exe, and have fun!